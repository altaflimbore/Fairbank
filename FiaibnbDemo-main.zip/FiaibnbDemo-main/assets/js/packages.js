// Accounts page functionality for FairBank (Demo Only)
// NOTE: This is for demo purposes only. Do NOT use in production for real banking security.
document.addEventListener('DOMContentLoaded', () => {
    renderAccounts();
});

// Render accounts as cards
function renderAccounts() {
    const accountsList = document.getElementById('accounts-list');
    if (!accountsList) return;
    accountsList.innerHTML = '';
    accounts.forEach(acc => {
        const card = document.createElement('div');
        card.className = 'account-card';
        card.innerHTML = `
            <h3>${acc.type} Account</h3>
            <p><strong>Account Number:</strong> ${acc.number}</p>
            <p><strong>Balance:</strong> ₹${acc.balance.toLocaleString()} ${acc.currency}</p>
        `;
        accountsList.appendChild(card);
    });
}
