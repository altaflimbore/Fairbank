// Demo data for accounts and transactions (Banking Demo)

const accounts = [
    {
        id: 1,
        type: 'Savings',
        number: '1234567890',
        balance: 25000.50,
        currency: 'INR',
    },
    {
        id: 2,
        type: 'Current',
        number: '9876543210',
        balance: 120000.00,
        currency: 'INR',
    }
];

const transactions = [
    {
        id: 1,
        date: '2024-06-01',
        description: 'ATM Withdrawal',
        amount: -2000,
        account: '1234567890',
        type: 'debit',
    },
    {
        id: 2,
        date: '2024-05-28',
        description: 'Salary Credit',
        amount: 50000,
        account: '1234567890',
        type: 'credit',
    },
    {
        id: 3,
        date: '2024-05-25',
        description: 'Online Transfer',
        amount: -5000,
        account: '9876543210',
        type: 'debit',
    },
    {
        id: 4,
        date: '2024-05-20',
        description: 'Cheque Deposit',
        amount: 20000,
        account: '9876543210',
        type: 'credit',
    }
];
