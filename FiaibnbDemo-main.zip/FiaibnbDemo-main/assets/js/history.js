// Transactions page functionality for FairBank (Demo Only)
// NOTE: This is for demo purposes only. Do NOT use in production for real banking security.
document.addEventListener('DOMContentLoaded', () => {
    loadTransactions();
});

// Load and render transactions
function loadTransactions() {
    const tbody = document.getElementById('transactions-body');
    if (!tbody) return;
    tbody.innerHTML = '';
    transactions.forEach(txn => {
        const tr = document.createElement('tr');
        tr.innerHTML = `
            <td>${txn.date}</td>
            <td>${txn.description}</td>
            <td>${txn.account}</td>
            <td class="${txn.type === 'debit' ? 'debit' : 'credit'}">${txn.type === 'debit' ? '-' : '+'}₹${Math.abs(txn.amount).toLocaleString()}</td>
            <td>${txn.type.charAt(0).toUpperCase() + txn.type.slice(1)}</td>
        `;
        tbody.appendChild(tr);
    });
}
