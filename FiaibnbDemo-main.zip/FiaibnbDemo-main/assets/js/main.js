// Main UI logic for FairBank (Demo Only)
// NOTE: This is for demo purposes only. Do NOT use in production for real banking security.
let currentUser = null;

document.addEventListener('DOMContentLoaded', () => {
    initializeAuth();
    setupMobileNav();
});

// Initialize authentication state
function initializeAuth() {
    const savedUser = localStorage.getItem('fairbank_user');
    if (savedUser) {
        currentUser = JSON.parse(savedUser);
        updateNavbar();
    }
}

// Update navbar based on auth state
function updateNavbar() {
    const authSection = document.getElementById('auth-section');
    if (!authSection) return;
    if (currentUser) {
        authSection.innerHTML = `
            <span class="user-name">Hi, ${currentUser.name}</span>
            <a href="#" class="nav-link" onclick="signOut()">Sign Out</a>
        `;
    } else {
        authSection.innerHTML = `
            <a href="signin.html" class="nav-link" id="auth-link">Sign In</a>
        `;
    }
}

// Sign out function
function signOut() {
    localStorage.removeItem('fairbank_user');
    currentUser = null;
    showAlert('Signed out successfully!', 'success');
    setTimeout(() => {
        window.location.href = 'index.html';
    }, 1000);
}

// Setup mobile navigation
function setupMobileNav() {
    const navToggle = document.getElementById('nav-toggle');
    const navMenu = document.getElementById('nav-menu');
    if (navToggle && navMenu) {
        navToggle.addEventListener('click', () => {
            navMenu.classList.toggle('active');
            navToggle.classList.toggle('active');
        });
    }
}

// Show alert message (demo only)
function showAlert(message, type = 'info') {
    // Remove existing alert if any
    const oldAlert = document.getElementById('demo-alert');
    if (oldAlert) oldAlert.remove();
    const alert = document.createElement('div');
    alert.id = 'demo-alert';
    alert.className = `demo-alert ${type}`;
    alert.textContent = message;
    document.body.appendChild(alert);
    setTimeout(() => {
        alert.remove();
    }, 2500);
}

// Load accounts on accounts.html
function loadAccounts() {
    let accounts = loadAccountsFromLocalStorage();
    if (accounts.length === 0 && window.accounts) accounts = window.accounts;
    window.accounts = accounts;

    const accountsList = document.getElementById('accounts-list');
    if (!accountsList) return;
    accountsList.innerHTML = '';
    accounts.forEach(acc => {
        const nickname = acc.nickname ? `<p><strong>Nickname:</strong> ${acc.nickname}</p>` : '';
        const card = document.createElement('div');
        card.className = 'account-card';
        card.innerHTML = `
            <h3>${acc.type} Account</h3>
            <p><strong>Account Number:</strong> ${acc.number}</p>
            ${nickname}
            <p><strong>Balance:</strong> ₹${acc.balance.toLocaleString()} ${acc.currency}</p>
        `;
        accountsList.appendChild(card);
    });
}

// Format currency in INR
function formatCurrency(amount) {
    return `₹${amount.toLocaleString('en-IN')}`;
}

// Format date
function formatDate(date) {
    return new Date(date).toLocaleDateString('en-IN', {
        year: 'numeric',
        month: 'long',
        day: 'numeric'
    });
}

// Check if user is logged in
function requireAuth() {
    if (!currentUser) {
        showAlert('Please sign in to access this feature.', 'error');
        setTimeout(() => {
            window.location.href = 'signin.html';
        }, 1500);
        return false;
    }
    return true;
}

// Session management
function saveUserSession(user) {
    currentUser = user;
    localStorage.setItem('fairbank_user', JSON.stringify(user));
    updateNavbar();
}

// Show/Hide modal logic
document.getElementById('open-account-btn').onclick = function() {
    document.getElementById('open-account-modal').style.display = 'block';
};
document.getElementById('close-account-modal').onclick = function() {
    document.getElementById('open-account-modal').style.display = 'none';
};
window.onclick = function(event) {
    if (event.target == document.getElementById('open-account-modal')) {
        document.getElementById('open-account-modal').style.display = 'none';
    }
};

// Handle account creation
document.getElementById('open-account-form').onsubmit = function(e) {
    e.preventDefault();
    const type = document.getElementById('account-type').value;
    const deposit = parseFloat(document.getElementById('initial-deposit').value) || 0;
    const nickname = document.getElementById('account-nickname').value.trim();

    if (!type) {
        alert('Please select an account type.');
        return;
    }

    // Only use user-specific accounts
    let accounts = loadAccountsFromLocalStorage();

    // Generate a new account number
    const number = Math.floor(1000000000 + Math.random() * 9000000000).toString();
    const newAccount = {
        id: Date.now(),
        type,
        number,
        balance: deposit,
        currency: 'INR',
        nickname: nickname || undefined
    };
    accounts.push(newAccount);
    saveAccountsToLocalStorage(accounts);

    // Show confirmation message
    const msg = document.getElementById('account-success-message');
    msg.textContent = `Account created successfully! Your new account number is ${number}.`;
    msg.style.display = 'block';

    // Optionally, reset the form
    e.target.reset();

    // Reload accounts list after a short delay and close modal
    setTimeout(() => {
        document.getElementById('open-account-modal').style.display = 'none';
        msg.style.display = 'none';
        if (typeof loadAccounts === 'function') loadAccounts();
    }, 2000);
};

// Generate unique ID
function generateId() {
    return '_' + Math.random().toString(36).substr(2, 9);
}

// Utility functions for localStorage account management
function saveAccountsToLocalStorage(accounts) {
    if (!currentUser || !currentUser.email) return;
    localStorage.setItem(`fairbank_accounts_${currentUser.email}`, JSON.stringify(accounts));
}

function loadAccountsFromLocalStorage() {
    if (!currentUser || !currentUser.email) return [];
    return JSON.parse(localStorage.getItem(`fairbank_accounts_${currentUser.email}`) || '[]');
}
