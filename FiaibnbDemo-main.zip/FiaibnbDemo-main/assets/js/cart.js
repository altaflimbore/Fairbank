// Transfer page functionality for FairBank (Demo Only)
// NOTE: This is for demo purposes only. Do NOT use in production for real banking security.
document.addEventListener('DOMContentLoaded', () => {
    setupTransferForm();
});

// Setup transfer form handler
function setupTransferForm() {
    const transferForm = document.getElementById('transfer-form');
    if (transferForm) {
        transferForm.addEventListener('submit', handleTransferSubmit);
    }
}

// Handle transfer form submission (demo only)
function handleTransferSubmit(event) {
    event.preventDefault();
    const fromAccount = document.getElementById('from-account').value;
    const toAccount = document.getElementById('to-account').value;
    const amount = parseFloat(document.getElementById('amount').value);

    // Simple validation
    if (!fromAccount || !toAccount || isNaN(amount) || amount <= 0) {
        showAlert('Please fill in all fields with valid values.', 'error');
        return;
    }
    if (fromAccount === toAccount) {
        showAlert('Cannot transfer to the same account.', 'error');
        return;
    }
    // Demo: Show success alert and reset form
    showAlert('Transfer feature coming soon! (Demo only)', 'info');
    event.target.reset();
}
